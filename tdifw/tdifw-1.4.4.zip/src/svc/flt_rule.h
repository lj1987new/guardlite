// $Id: flt_rule.h,v 1.1.1.1 2002/09/24 11:12:16 dev Exp $

#ifndef _flt_rule_h_
#define _flt_rule_h_

#include "filter.h"

int		parse_rule(char *str, struct flt_rule *rule);

#endif
